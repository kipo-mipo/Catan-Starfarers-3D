using System.Collections.Generic;
using Mirror;

namespace MyAssets.Net
{
    internal sealed class NetLobbyDirectory
    {
        private readonly int _minPlayersToStart;
        private int? _dedicatedHostConnectionId;

        private readonly Dictionary<int, LobbyPlayerState> _roster = new();

        public NetLobbyDirectory(int minPlayersToStart)
        {
            _minPlayersToStart = minPlayersToStart < 1 ? 1 : minPlayersToStart;
        }

        public int PlayerCount => _roster.Count;

        public IEnumerable<int> ConnectionIds => _roster.Keys;

        public void OnServerConnected(NetworkConnectionToClient conn)
        {
            if (_dedicatedHostConnectionId == null)
                _dedicatedHostConnectionId = conn.connectionId;

            if (!_roster.ContainsKey(conn.connectionId))
            {
                _roster[conn.connectionId] = new LobbyPlayerState
                {
                    ConnectionId = conn.connectionId,
                    Name = $"Player {conn.connectionId}",
                    Ready = false
                };
            }
        }

        public void OnServerDisconnected(NetworkConnectionToClient conn)
        {
            _roster.Remove(conn.connectionId);

            if (NetworkServer.localConnection == null && _dedicatedHostConnectionId == conn.connectionId)
            {
                _dedicatedHostConnectionId = null;
                foreach (var kv in NetworkServer.connections)
                {
                    _dedicatedHostConnectionId = kv.Key;
                    break;
                }
            }
        }

        public void OnJoinLobby(NetworkConnectionToClient conn, JoinLobbyRequest msg)
        {
            var name = string.IsNullOrWhiteSpace(msg.PlayerName) ? $"Player {conn.connectionId}" : msg.PlayerName.Trim();

            _roster[conn.connectionId] = new LobbyPlayerState
            {
                ConnectionId = conn.connectionId,
                Name = name,
                Ready = _roster.TryGetValue(conn.connectionId, out var prev) && prev.Ready
            };
        }

        public void OnSetReady(NetworkConnectionToClient conn, SetReadyRequest msg)
        {
            if (_roster.TryGetValue(conn.connectionId, out var p))
            {
                p.Ready = msg.Ready;
                _roster[conn.connectionId] = p;
            }
        }

        public LobbyStateMessage BuildLobbyState()
        {
            var players = new LobbyPlayerState[_roster.Count];
            int i = 0;
            foreach (var kv in _roster)
                players[i++] = kv.Value;

            bool canStart = players.Length >= _minPlayersToStart;

            return new LobbyStateMessage
            {
                Players = players,
                CanStart = canStart
            };
        }

        public bool CanStartMatch() => _roster.Count >= _minPlayersToStart;

        public bool IsHostConnection(NetworkConnectionToClient conn)
        {
            if (NetworkServer.localConnection != null)
                return ReferenceEquals(conn, NetworkServer.localConnection);

            return _dedicatedHostConnectionId != null && conn.connectionId == _dedicatedHostConnectionId.Value;
        }
    }
}
