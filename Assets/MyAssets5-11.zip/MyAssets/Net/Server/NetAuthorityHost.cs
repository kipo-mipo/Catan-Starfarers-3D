using System.Collections.Generic;
using Mirror;
using MyAssets.GameCore;
using UnityEngine;

namespace MyAssets.Net
{
    public sealed class NetAuthorityHost : NetworkBehaviour
    {
        [Header("Lobby")]
        [SerializeField] private int minPlayersToStart = 2;

        private NetLobbyDirectory _lobby;
        private NetMatchOrchestrator _match;

        public override void OnStartServer()
        {
            base.OnStartServer();

            _lobby = new NetLobbyDirectory(minPlayersToStart);
            _match = new NetMatchOrchestrator();

            NetworkServer.OnConnectedEvent -= OnServerConnected;
            NetworkServer.OnConnectedEvent += OnServerConnected;

            NetworkServer.OnDisconnectedEvent -= OnServerDisconnected;
            NetworkServer.OnDisconnectedEvent += OnServerDisconnected;

            NetworkServer.RegisterHandler<JoinLobbyRequest>(OnJoinLobbyRequest);
            NetworkServer.RegisterHandler<SetReadyRequest>(OnSetReadyRequest);

            NetworkServer.RegisterHandler<StartMatchRequest>(OnStartMatchRequest);
            NetworkServer.RegisterHandler<ChooseStartNodeRequest>(OnChooseStartNodeRequest);
            NetworkServer.RegisterHandler<MoveShipRequest>(OnMoveShipRequest);
        }

        public override void OnStopServer()
        {
            base.OnStopServer();
            NetworkServer.OnConnectedEvent -= OnServerConnected;
            NetworkServer.OnDisconnectedEvent -= OnServerDisconnected;
        }

        private void OnServerConnected(NetworkConnectionToClient conn)
        {
            _lobby.OnServerConnected(conn);
            BroadcastLobby();
        }

        private void OnServerDisconnected(NetworkConnectionToClient conn)
        {
            _lobby.OnServerDisconnected(conn);
            BroadcastLobby();
        }

        private void OnJoinLobbyRequest(NetworkConnectionToClient conn, JoinLobbyRequest msg)
        {
            _lobby.OnJoinLobby(conn, msg);
            BroadcastLobby();
        }

        private void OnSetReadyRequest(NetworkConnectionToClient conn, SetReadyRequest msg)
        {
            _lobby.OnSetReady(conn, msg);
            BroadcastLobby();
        }

        private void BroadcastLobby()
        {
            NetworkServer.SendToAll(_lobby.BuildLobbyState());
        }

        private void OnStartMatchRequest(NetworkConnectionToClient conn, StartMatchRequest msg)
        {
            if (!_lobby.IsHostConnection(conn))
            {
                conn.Send(new CoreEventMessage { EventType = EventTypes.Rejected });
                return;
            }

            if (!_lobby.CanStartMatch())
            {
                conn.Send(new CoreEventMessage { EventType = EventTypes.Rejected });
                return;
            }

            // PlayerId == connectionId (for now). This is the single source of truth.
            var playerIds = new List<PlayerId>(_lobby.PlayerCount);
            foreach (var cid in _lobby.ConnectionIds)
                playerIds.Add(new PlayerId(cid));

            var events = _match.StartMatch(msg.Seed, playerIds);
            BroadcastEvents(events);
        }

        private void OnChooseStartNodeRequest(NetworkConnectionToClient conn, ChooseStartNodeRequest msg)
        {
            // PlayerId == connectionId (server authoritative mapping)
            var player = new PlayerId(conn.connectionId);
            var events = _match.ChooseStartNode(player, msg.NodeId);
            BroadcastEvents(events);
        }

        private void OnMoveShipRequest(NetworkConnectionToClient conn, MoveShipRequest msg)
        {
            var events = _match.MoveShip(msg);
            BroadcastEvents(events);
        }

        private static void BroadcastEvents(List<IGameEvent> events)
        {
            foreach (var e in events)
                NetworkServer.SendToAll(NetEventEncoder.ToMessage(e));
        }
    }
}
