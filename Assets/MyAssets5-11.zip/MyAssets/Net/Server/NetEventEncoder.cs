using MyAssets.GameCore;

namespace MyAssets.Net
{
    internal static class NetEventEncoder
    {
        public static CoreEventMessage ToMessage(IGameEvent e)
        {
            return e switch
            {
                MatchStartedEvent ms => new CoreEventMessage { EventType = EventTypes.MatchStarted, A = ms.Seed },

                ShipPlacedEvent sp => new CoreEventMessage
                {
                    EventType = EventTypes.ShipPlaced,
                    A = sp.Player.Value,
                    B = sp.Ship.Value,
                    C = sp.Node.Value
                },

                SetupCompletedEvent sc => new CoreEventMessage
                {
                    EventType = EventTypes.SetupCompleted,
                    A = sc.FirstPlayer.Value
                },

                ShipMovedEvent sm => new CoreEventMessage
                {
                    EventType = EventTypes.ShipMoved,
                    A = sm.Player.Value,
                    B = sm.Ship.Value,
                    C = sm.From.Value,
                    D = sm.To.Value
                },

                SectorRevealedEvent sr => new CoreEventMessage
                {
                    EventType = EventTypes.SectorRevealed,
                    A = sr.Slot.Value,
                    B = sr.Piece.Value,
                    C = sr.Rotation
                },

                ActionRejectedEvent _ => new CoreEventMessage { EventType = EventTypes.Rejected },
                _ => new CoreEventMessage { EventType = EventTypes.Rejected }
            };
        }
    }
}
