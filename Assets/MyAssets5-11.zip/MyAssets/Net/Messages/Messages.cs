using Mirror;

namespace MyAssets.Net
{
    // ===== Lobby =====
    public struct JoinLobbyRequest : NetworkMessage
    {
        public string PlayerName;
    }

    public struct SetReadyRequest : NetworkMessage
    {
        public bool Ready;
    }

    public struct LobbyPlayerState
    {
        public int ConnectionId;
        public string Name;
        public bool Ready;
    }

    /// <summary>
    /// Server -> clients lobby snapshot.
    /// </summary>
    public struct LobbyStateMessage : NetworkMessage
    {
        public LobbyPlayerState[] Players;
        public bool CanStart;
    }

    // ===== Match =====
    public struct StartMatchRequest : NetworkMessage
    {
        public int Seed;
    }

    public struct ChooseStartNodeRequest : NetworkMessage
    {
        public int NodeId;
    }

    public struct MoveShipRequest : NetworkMessage
    {
        public int Player;
        public int Ship;
        public int FromNode;
        public int ToNode;
    }

    // ===== Core Event Pump =====
    public struct CoreEventMessage : NetworkMessage
    {
        public byte EventType;
        public int A; public int B; public int C; public int D;
    }

    static class EventTypes
    {
        public const byte MatchStarted = 1;
        public const byte ShipMoved = 2;
        public const byte SectorRevealed = 3;

        public const byte ShipPlaced = 4;
        public const byte SetupCompleted = 5;

        public const byte Rejected = 255;
    }
}
