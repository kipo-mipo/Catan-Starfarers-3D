namespace MyAssets.GameCore
{
    public enum MatchPhase { Setup, Turn, GameOver }

    public enum SectorType
    {
        Empty,
        Planet,
        TradeStation
    }

    public enum ResourceType
    {
        None,
        Ore,
        Carbon,
        Food,
        Goods,
        Fuel,
    }

    public enum UpgradeType
    {
        FreightPod,
        Cannon,
        Booster,
    }
}
