using System.Collections.Generic;

namespace MyAssets.GameCore
{
    public sealed class GameState
    {
        public MatchPhase Phase { get; internal set; } = MatchPhase.Setup;

        public BoardDefinitionData BoardDef { get; }
        public BoardGraph Graph { get; }
        public SetupDefinitionData Setup { get; }
        public TileLibraryData Tiles { get; }

        // Authoritative placements:
        public readonly Dictionary<SlotId, TileId> SlotToTile;

        // Fog-of-war: revealed slots (public once revealed)
        public readonly Dictionary<SlotId, SectorPieceId> SlotToPiece = new();
        public readonly Dictionary<SlotId, int> SlotToRotation = new();
        public readonly HashSet<SlotId> RevealedSlots = new();

        // Planet token state (per planet instance).
        // NOTE: PlanetTokenState is defined in Board/PlanetTokens.cs (TokenState/Pool/TokenId/Rolls).
        public readonly Dictionary<PlanetInstanceId, PlanetTokenState> PlanetTokens = new();

        // Ships
        public readonly Dictionary<ShipId, NodeId> ShipPositions = new();
        public readonly Dictionary<ShipId, PlayerId> ShipOwners = new();

        // Setup selection tracking
        public readonly HashSet<PlayerId> SetupPlayers = new();
        public readonly Dictionary<PlayerId, NodeId> StartingNodeByPlayer = new();

        public GameState(BoardDefinitionData boardDef, SetupDefinitionData setup, TileLibraryData tiles)
        {
            BoardDef = boardDef;
            Setup = setup;
            Tiles = tiles;
            Graph = new BoardGraph(boardDef);
            SlotToTile = new Dictionary<SlotId, TileId>(setup.SlotToTile);

            // Pre-reveal starting slots (if any in setup)
            foreach (var slot in setup.SlotToTile.Keys)
            {
                // no-op: slots get revealed from ship vision later
            }
        }
    }
}
