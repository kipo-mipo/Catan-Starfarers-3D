using System.Collections.Generic;

namespace MyAssets.GameCore
{
    public sealed class RulesEngine
    {
        private readonly GameState _state;

        public RulesEngine(GameState state) => _state = state;

        public List<IGameEvent> Apply(IGameAction action)
        {
            var ev = new List<IGameEvent>();

            switch (action)
            {
                case StartMatchAction start:
                    _state.Phase = MatchPhase.Setup;
                    ev.Add(new MatchStartedEvent(start.Seed));
                    RevealFromAllShips(ev);
                    return ev;

                case ChooseStartingNodeAction choose:
                    if (_state.Phase != MatchPhase.Setup)
                        return Reject(ev, "Not in Setup phase.");

                    if (!_state.SetupPlayers.Contains(choose.Player))
                        return Reject(ev, "Unknown player for this match.");

                    if (_state.StartingNodeByPlayer.ContainsKey(choose.Player))
                        return Reject(ev, "Player already placed a starting ship.");

                    if (!_state.Graph.HasNode(choose.Node))
                        return Reject(ev, "Invalid node.");

                    if (!_state.Graph.IsLandable(choose.Node))
                        return Reject(ev, "Cannot place a ship on a planet sector slot.");

                    foreach (var kv in _state.StartingNodeByPlayer)
                        if (kv.Value.Equals(choose.Node))
                            return Reject(ev, "Node already taken.");

                    var ship = new ShipId(choose.Player.Value);

                    _state.ShipOwners[ship] = choose.Player;
                    _state.ShipPositions[ship] = choose.Node;
                    _state.StartingNodeByPlayer[choose.Player] = choose.Node;

                    ev.Add(new ShipPlacedEvent(choose.Player, ship, choose.Node));
                    RevealFromNode(choose.Node, ev);

                    if (_state.StartingNodeByPlayer.Count >= _state.SetupPlayers.Count && _state.SetupPlayers.Count > 0)
                    {
                        _state.Phase = MatchPhase.Turn;

                        int min = int.MaxValue;
                        foreach (var p in _state.SetupPlayers)
                            if (p.Value < min) min = p.Value;

                        ev.Add(new SetupCompletedEvent(new PlayerId(min)));
                    }

                    return ev;

                case MoveShipAction move:
                    if (_state.Phase != MatchPhase.Turn)
                        return Reject(ev, "Not in Turn phase.");

                    if (!_state.ShipOwners.TryGetValue(move.Ship, out var owner) || !owner.Equals(move.Player))
                        return Reject(ev, "Not your ship.");

                    if (!_state.ShipPositions.TryGetValue(move.Ship, out var pos) || !pos.Equals(move.From))
                        return Reject(ev, "Ship is not at From node.");

                    if (!_state.Graph.IsPassable(move.From))
                        return Reject(ev, "Ship is on a blocked node.");

                    if (!_state.Graph.IsLandable(move.To))
                        return Reject(ev, "Cannot move onto a planet sector slot.");

                    if (!_state.Graph.AreAdjacent(move.From, move.To))
                        return Reject(ev, "Nodes are not adjacent.");

                    _state.ShipPositions[move.Ship] = move.To;
                    ev.Add(new ShipMovedEvent(move.Player, move.Ship, move.From, move.To));

                    RevealFromNode(move.To, ev);
                    return ev;

                case EndTurnAction end:
                    if (_state.Phase != MatchPhase.Turn)
                        return Reject(ev, "Not in Turn phase.");
                    return ev;

                case SettleNextToPlanetAction settle:
                    return ev;

                default:
                    return Reject(ev, "Unknown action.");
            }
        }

        private bool HasNode(NodeId id)
        {
            // BoardGraph doesn't expose HasNode in your codebase; use BoardDef.
            foreach (var n in _state.BoardDef.Nodes)
                if (n.Id.Equals(id))
                    return true;
            return false;
        }

        private static List<IGameEvent> Reject(List<IGameEvent> ev, string reason)
        {
            ev.Add(new ActionRejectedEvent(reason));
            return ev;
        }

        private void RevealFromAllShips(List<IGameEvent> ev)
        {
            foreach (var kv in _state.ShipPositions)
                RevealFromNode(kv.Value, ev);
        }

        private void RevealFromNode(NodeId node, List<IGameEvent> ev)
        {
            // TODO: vision + graph reveal
        }
    }
}
