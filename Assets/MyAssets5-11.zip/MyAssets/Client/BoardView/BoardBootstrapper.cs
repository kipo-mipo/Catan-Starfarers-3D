using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using MyAssets.Client.Net;
using MyAssets.GameCore;
using MyAssets.GameCore.Net;

namespace MyAssets.Client.BoardView
{
    public sealed class BoardBootstrapper : MonoBehaviour
    {
        [SerializeField] private BoardSpawner spawner;
        [SerializeField] private float hexsize = .5f;
        [SerializeField] private PlayerCountMode playerCountMode = PlayerCountMode.Four;
        [SerializeField] private int setupSeed = 12345;

        private INetBridge _bridge;

        private void Awake()
        {
            if (spawner == null) spawner = GetComponent<BoardSpawner>();
            if (spawner == null) Debug.LogError("[BoardBootstrapper] No BoardSpawner found/assigned.");
        }

        private void OnEnable()
        {
            StartCoroutine(HookWhenBridgeExists());
        }

        private void OnDisable()
        {
            if (_bridge != null) _bridge.OnGameEvent -= OnEvent;
            _bridge = null;
        }

        private IEnumerator HookWhenBridgeExists()
        {
            while (true)
            {
                var b = NetService.Bridge;
                if (b != null)
                {
                    _bridge = b;
                    _bridge.OnGameEvent += OnEvent;
                    Debug.Log("[BoardBootstrapper] Hooked OnGameEvent.");
                    yield break;
                }
                yield return null;
            }
        }

        private void OnEvent(IGameEvent e)
        {
            if (e is MatchStartedEvent)
                SpawnBoardAndSectors();
        }

        private void SpawnBoardAndSectors()
        {
            if (spawner == null)
            {
                Debug.LogError("[BoardBootstrapper] Can't spawn: spawner is null.");
                return;
            }

            var board = BoardGenerator.Generate(hexsize);
            spawner.Spawn(board);

            var pieces = SectorPieceLibraryFactory.CreateDefault();
            var rules = SetupRules.For(playerCountMode);
            var setup = SetupGenerator.Generate(board, pieces, rules, setupSeed);
            var starterSlotToPiece = BuildStarterSlotToPiece(board);

            if (starterSlotToPiece.Count == 0)
                return;

            var allPlacedPieces = new Dictionary<SlotId, SectorPieceId>();
            foreach (var pair in setup.SlotToPiece)
                allPlacedPieces[pair.Key] = pair.Value;
            foreach (var pair in starterSlotToPiece)
                allPlacedPieces[pair.Key] = pair.Value;

            var tokenLibrary = TokenLibraryFactory.CreateDefault(playerCountMode);
            var tokenSetup = TokenSetupGenerator.Generate(
                pieces,
                allPlacedPieces,
                tokenLibrary,
                setupSeed);

            foreach (var pair in setup.SlotToPiece)
            {
                var slotId = pair.Key;
                var pieceId = pair.Value;
                var pieceDef = pieces.Pieces[pieceId];
                var rotation = setup.SlotToRotation[slotId];

                spawner.SpawnSectorPieceIntoSlot(slotId, pieceDef, rotation, tokenSetup);
            }

            SpawnStartingSectors(pieces, starterSlotToPiece, tokenSetup);

            Debug.Log($"[BoardBootstrapper] Board, sectors, starting sectors, and tokens spawned. Unused piece: {setup.UnusedPiece.Value}.");
        }

        private Dictionary<SlotId, SectorPieceId> BuildStarterSlotToPiece(BoardDefinitionData board)
        {
            var starterPieceIds = new[]
            {
                new SectorPieceId(300),
                new SectorPieceId(301),
                new SectorPieceId(302),
                new SectorPieceId(303),
            };

            var startingSlots = board.Slots
                .Where(slot => board.StartingSlots.Contains(slot.Id))
                .OrderBy(slot => slot.Id.Value)
                .ToList();

            if (startingSlots.Count != starterPieceIds.Length)
            {
                Debug.LogError($"[BoardBootstrapper] Expected {starterPieceIds.Length} starting slots, got {startingSlots.Count}.");
                return new Dictionary<SlotId, SectorPieceId>();
            }

            var mapping = new Dictionary<SlotId, SectorPieceId>();
            for (int i = 0; i < starterPieceIds.Length; i++)
                mapping[startingSlots[i].Id] = starterPieceIds[i];

            return mapping;
        }

        private void SpawnStartingSectors(
            SectorPieceLibraryData pieces,
            IReadOnlyDictionary<SlotId, SectorPieceId> starterSlotToPiece,
            TokenSetupResult tokenSetup)
        {
            foreach (var pair in starterSlotToPiece)
            {
                var slotId = pair.Key;
                var pieceId = pair.Value;

                if (!pieces.Pieces.TryGetValue(pieceId, out var pieceDef))
                {
                    Debug.LogError($"[BoardBootstrapper] Missing starter sector piece {pieceId.Value}.");
                    continue;
                }

                spawner.SpawnSectorPieceIntoSlot(slotId, pieceDef, rotation: 0, tokenSetup);
            }
        }
    }
}
