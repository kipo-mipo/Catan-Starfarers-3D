using UnityEngine;
using MyAssets.Client.Net;
using MyAssets.GameCore;

namespace MyAssets.Client.Input
{
    public sealed class SelectionController : MonoBehaviour
    {
        [Header("Temp selection")]
        public int localPlayerId = 0;
        public int selectedShipId = 0;

        [Header("Refs")]
        [SerializeField] private ClientSessionModel session;

        private int? _fromNode;

        private void Awake()
        {
            if (session == null)
                session = FindAnyObjectByType<ClientSessionModel>();
        }

        public void OnNodeClicked(int nodeId)
        {
            if (session != null)
                session.LocalPlayerId = localPlayerId;

            // Setup phase: single click selects starting node (one-time)
            if (session != null && session.Phase == MatchPhase.Setup)
            {
                if (session.LocalPlacedStartShip)
                {
                    Debug.Log("Start ship already placed.");
                    return;
                }

                NetService.Bridge?.RequestChooseStartNode(nodeId);
                Debug.Log($"ChooseStartNode requested: {nodeId}");
                return;
            }

            // Turn phase: two-click move (from -> to)
            if (_fromNode is null)
            {
                _fromNode = nodeId;
                Debug.Log($"From selected: {nodeId}");
                return;
            }

            NetService.Bridge?.RequestMoveShip(localPlayerId, selectedShipId, _fromNode.Value, nodeId);
            Debug.Log($"MoveShip requested: {_fromNode.Value} -> {nodeId}");
            _fromNode = null;
        }
    }
}
