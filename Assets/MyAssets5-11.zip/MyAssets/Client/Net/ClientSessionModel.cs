using System.Collections.Generic;
using UnityEngine;
using MyAssets.GameCore;

namespace MyAssets.Client.Net
{
    /// <summary>
    /// Client-side projection of authoritative server events.
    /// Keeps UI/input phase-aware without embedding game rules in UI code.
    /// </summary>
    public sealed class ClientSessionModel : MonoBehaviour
    {
        public MatchPhase Phase { get; private set; } = MatchPhase.Setup;

        public readonly Dictionary<int, int> ShipToNode = new();   // shipId -> nodeId
        public readonly Dictionary<int, int> ShipToPlayer = new(); // shipId -> playerId

        public int LocalPlayerId = 0; // for now: set in inspector to match connectionId if needed

        public bool LocalPlacedStartShip => ShipToPlayer.ContainsValue(LocalPlayerId);

        private void OnEnable()
        {
            var bridge = NetService.Bridge;
            if (bridge == null) return;
            bridge.OnGameEvent += OnEvent;
        }

        private void OnDisable()
        {
            var bridge = NetService.Bridge;
            if (bridge == null) return;
            bridge.OnGameEvent -= OnEvent;
        }

        private void OnEvent(IGameEvent e)
        {
            switch (e)
            {
                case MatchStartedEvent:
                    Phase = MatchPhase.Setup;
                    break;

                case ShipPlacedEvent sp:
                    ShipToNode[sp.Ship.Value] = sp.Node.Value;
                    ShipToPlayer[sp.Ship.Value] = sp.Player.Value;
                    break;

                case SetupCompletedEvent:
                    Phase = MatchPhase.Turn;
                    break;

                case ShipMovedEvent sm:
                    ShipToNode[sm.Ship.Value] = sm.To.Value;
                    break;
            }
        }
    }
}
